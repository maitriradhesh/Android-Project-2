package com.example.homework20;

import android.os.Bundle;
import android.content.Intent;

import android.widget.EditText;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AddContactActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);

        EditText etName = findViewById(R.id.etName);
        EditText etPhoneNumber = findViewById(R.id.etPhoneNumber);
        EditText etEmail = findViewById(R.id.etEmail);
        Button btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String phoneNumber = etPhoneNumber.getText().toString();
            String email = etEmail.getText().toString();

            String contactInfo = "Name: " + name + "\nPhone: " + phoneNumber + "\nEmail: " + email;

            Intent resultIntent = new Intent();
            resultIntent.putExtra("contactInfo", contactInfo);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}