package com.example.homework20;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import androidx.annotation.Nullable;
import android.widget.TextView;

import android.widget.Button;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private TextView tvContactInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvContactInfo = findViewById(R.id.tvContactInfo);
        Button btnAddContact = findViewById(R.id.btnAddContact);

        btnAddContact.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddContactActivity.class);
            startActivityForResult(intent, 1);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            String contactInfo = data.getStringExtra("contactInfo");
            tvContactInfo.setText(contactInfo);
        }
    }
}